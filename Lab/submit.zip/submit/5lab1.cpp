#include<bits/stdc++.h>
using namespace std;

class Number
{
 int num;
 public:
 Number()
 {
    num=0;
 }   
 Number(int l)
 {
    num=l;
 }
 ~Number()
 {
    cout<<"object destroyed for class Num\n";
 }
 int getNumber()   // Accessor
 {
    return num;
 }
 void changeNumber(int m)  // Mutator
 {
    num=m;
 }
 bool isArmstrong()
 {
    int n=num,r,temp=0,digit=0,to=num;
    if(to==0)
        digit=1;
    else
        {
            while(to!=0)
            {
            to=to/10;
            digit++;    
            }
        }
    while(n!=0)
    {
        r=n%10;
        temp+=pow(r,digit);
        n=n/10;
    }
    if(num==temp)
        return 1;
    else 
        return 0;
 }
 
 bool isPrime()
 {
    int n=num;
    for(int i=2;i<sqrt(n);i++)
    {
        if(n%i==0)
            return 0;
       
    }
    return 1;
 }
 int nextCoprime()
 {
    return num+1;
 }
 int reverse()// a bit problem
 {
    int n=num,r,temp=0,digit=0,to=num;
    if(to==0)
        digit=1;
    else
        {
            while(to!=0)
            {
            to=to/10;
            digit++;    
            }
        }
        digit--;
    while(n!=0)//1634
    {
        r=n%10;//1
        // cout<<r<<"    ";
        temp+=r*pow(10,digit);
        // cout<<temp<<" ";
        digit--;
        n=n/10;
    } 
    return temp;
 }

};


int main()
{
    Number a(6565565);
    // a.Number(371);
    // a(371);
    a.changeNumber(1634);
    cout<<a.getNumber()<<endl;
    cout<<a.isArmstrong()<<endl;
    cout<<a.isPrime()<<endl;
    cout<<a.nextCoprime()<<endl;
    cout<<a.reverse()<<endl;
    // a.~Number();
    return 0;
}