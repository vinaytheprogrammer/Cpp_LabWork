// Find the sum of numbers in a range of values between “lower” and “upper” using increment “inc”
#include <iostream>
using namespace std;

int sum(int,int =100,int =1);

int main(){
         cout<<sum(1) << endl;
         cout<<sum(1, 10)<< endl;
         cout<<sum(1, 10, 2)<< endl;
         return 0;
} 

int sum(int lower,int upper,int inc){
          int sum=0;
          for(int k=lower; k<=upper; k+= inc)
                sum += k;
return sum;
} 
