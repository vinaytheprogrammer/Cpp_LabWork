// demonstrates passing and returning a structure
#include <iostream>
using namespace std;

struct Distance {
	int feet;
	float inches;
};

Distance addDist(Distance, Distance); 
void dispDist(Distance);

int main() {
Distance d1, d2, d3;
    cout << "\nEnter feet: "; cin >> d1.feet;
    cout << "Enter inches: "; cin >> d1.inches;

    cout << "\nEnter feet: "; cin >> d2.feet;
    cout << "Enter inches: "; cin >> d2.inches;
    d3 = addDist(d1, d2);
    cout << endl;
    dispDist(d1); cout << " + "; 
    dispDist(d2); cout << " = ";
    dispDist(d3); cout << endl;
    return 0;
}

// adds two structures of type Distance, returns sum
Distance addDist( Distance dd1, Distance dd2 ) {
    Distance dd3;
    dd3.inches = dd1.inches + dd2.inches;
    dd3.feet = 0;
    if(dd3.inches >= 12.0) {
	dd3.inches -= 12.0; //by 12.0 and
	dd3.feet++; //increase feet
    } 
    dd3.feet += dd1.feet + dd2.feet; //add the feet
    return dd3; //return structure
}


void dispDist( Distance dd ) {
    cout << dd.feet << "\'-" << dd.inches << "\"";
}
