#include <iostream>
using namespace std;

class Distance{
	
	int feet;
	float inches;
	public:
	Distance(void){ cout << "Object created" <<endl; }
	~Distance(void){ cout << "Object destroyed" << endl; }
	void getdist() {
		cout << "\nEnter feet: "; cin >> feet;
		cout << "\nEnter inches: "; cin >> inches;
	}
	void showdist() { cout << feet << "\'-" << inches << '\"'<<endl; }	
};

int main(){
	Distance *ob1= new Distance();
	ob1->getdist();
	ob1->showdist();
	delete ob1;
	Distance *ob2= new Distance();
	ob2->getdist();
	ob2->showdist();
	delete ob2;
	return 0;
}

