#include <iostream>
using namespace std;

int main(){
    int **A;

    A = new int*[5];
    for (int i = 0; i < 5; i++) {
 	A[i] = new int[8];
 	for (int j = 0; j < 8; j++)
 		A[i][j] = i + j;
    }

    for (int i = 0; i < 5; i++) {
	for (int j = 0; j < 8; j++)
		cout << "   " << A[i][j];
        cout << endl;
    }

    for (int i = 0; i < 5; i++)
	delete [] A[i];
    delete [] A;

    return 0;
}
