#include <iostream>
using namespace std;
class Distance {
    private:
	int feet;
	float inches;
    public:
	void inputdist(void){
		cin >> feet >> inches;
	}
	int getFeet(void){
		return feet;
	}
	float getInches(void){
		return inches;
	}
	void add_dist( Distance, Distance );
};

void Distance::add_dist(Distance d2, Distance d3) {
	inches = d2.inches + d3.inches;
	feet = 0;
	if(inches >= 12.0) {
		inches -= 12.0;
		feet++;
	}
	feet += d2.feet + d3.feet;
}

int main() {
    Distance dist1, dist2, dist3;
    dist1.inputdist();
    dist2.inputdist();
    cout << "Distance 1 :" << dist1.getFeet() << " - " << dist1.getInches() << endl;
    cout << "Distance 2 :" << dist2.getFeet() << " - " << dist2.getInches() << endl;
    dist3.add_dist(dist1, dist2);
    cout << "Distance 3 :" << dist3.getFeet() << " - " << dist3.getInches() << endl;
    return 0;
}
