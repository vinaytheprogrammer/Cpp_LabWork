#include <iostream>
using namespace std;

//long int fact(int);
long int fact(int num){
	cout << "Inside fact function " << endl;
	long int res=1;	
	for(int i=1 ; i <=num ; i++)
		res = res * i;
	cout << "Leaving fact funcion " << endl;
	return res;
}

int main(){

	long int res;
	int n;
	cout << "Enter the number " << endl;
	cin >> n;
	res=fact(n);
	
	cout << "Factorial of " << n << " = " << res << endl;
}

