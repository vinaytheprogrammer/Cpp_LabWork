//demonstrates function call
#include <iostream>
using namespace std;

void repchar(char, int); //function declaration

int main() {
    repchar('-', 43); //call to function
    cout << "Data typ		Range" << endl;
    repchar('=', 23); 
    cout << "char		-128 to 127" << endl;
    cout << "short		-32,768 to 32,767" << endl;
    cout << "int		System dependent" << endl;
    cout << "double	-2,147,483,648 to 2,147,483,647" << endl;
    repchar('-', 43); 
    char chin; int nin;
    cout << "Enter a character: ";
    cin >> chin;
    cout << "Enter number of times to repeat it: ";
    cin >> nin;
    repchar(chin, nin);
    return 0;
}

void repchar(char ch, int n) {
    for(int j=0; j<n; j++)
	cout << ch;
    cout << endl;
}
