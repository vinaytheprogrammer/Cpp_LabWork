/*
Contact List implementation using Map of STL.
*/
#include<bits/stdc++.h>
using namespace std;

map<string,vector<string>> contact_list;

int main()
{
    int ch;
    string name,number;
    cout<<"\n1.Add contact.\n2.Display.\n3.Exit\n";
    while(1){
        cout<<"\nEnter choice: ";
        cin>>ch;
        switch(ch){
            case 1: cout<<"enter name: \n"; cin>>name;
                    cout<<"enter number: "; cin>>number;
                    contact_list[name].push_back(number); break;
            case 2: for(auto it: contact_list){
                cout<<it.first<<" :";
                for(auto i:it.second) cout<<i<<", ";
                cout<<endl;
            }
                    cout<<endl; break;
            case 3: exit(0);
        }
    }
    return 0;
}