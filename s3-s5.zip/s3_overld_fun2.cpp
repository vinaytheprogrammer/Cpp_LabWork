// demonstrates overloaded functions
#include <iostream>
using namespace std;

struct Distance {
    int feet;
    float inches;
};

void dispDist( Distance dd ) {
	cout << dd.feet << "\'-" << dd.inches << "\"";
}

void dispDist( float dd ) {
	int feet = static_cast<int>(dd / 12);
	float inches = dd - feet*12;
	cout << feet << "\'-" << inches << "\"";
}


int main() {
	Distance d1;
	float d2;
	cout << "\nEnter feet: "; 
	cin >> d1.feet;
	cout << "Enter inches: "; 
	cin >> d1.inches;
	cout << "Enter entire distance in inches: "; 	
	cin >> d2;
	cout << "\nd1 = ";
	dispDist(d1);
	cout << "\nd2 = ";
	dispDist(d2);
	cout << endl;
	return 0;
}
