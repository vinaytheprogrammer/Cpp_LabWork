#include <iostream>
using namespace std;

class FirstClass {
	private:
		int dataone;
		int datatwo;
	public:
		void setdata(int o, int t) 
			{ dataone = o; datatwo = t; showdata(); }
		void showdata(){ cout << "Data are " << dataone << ' '  << datatwo << endl; }
};

int main() {
	FirstClass s1, s2;
	s1.setdata(10,66);
	s2.setdata(17,76); 
	//s1.showdata(); 
	//s2.showdata(); 
	return 0; 
}
