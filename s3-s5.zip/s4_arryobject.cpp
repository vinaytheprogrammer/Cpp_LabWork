#include<iostream>
using namespace std;
class Coordinate2d {
		int x;
		int y;
	public:
	Coordinate2d(int j, int k) { x=j; y=k; } // constructor with 2 parameters
	void show() { cout << "(" << x << "," << y << ")" << endl; }
};
int main() {
	//Coordinate2d  ob[3] = { Coordinate2d (1, 2), Coordinate2d (3, 4), Coordinate2d (5, 6) };
	Coordinate2d  ob[3] = { {1, 2}, {3, 4}, {5, 6} };
	ob[0].show();
	return 0;
}
