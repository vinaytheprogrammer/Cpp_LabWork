/*
Write a file program to copy one file into another file. Use exception handling to
raise and handle exception for source file not found.

*/

#include <bits/stdc++.h>
using namespace std;

int main()
{
    try
    {
        ifstream fip;
        ofstream fop("copyTest.txt");
        fip.open("test.txt");
        if (!fip)
        {
            throw "unable to open the input file";
        }
        string s, line;
        // cin >> s;
        int l = s.length();
        while (getline(fip, line))
        {
            fop << line << endl;
        }
        fip.close();
        fop.close();
    }
    catch (const char *s)
    {
        cout << "Err:" << s << endl;
    }
    return 0;
}