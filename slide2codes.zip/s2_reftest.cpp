#include<iostream>

using namespace std;

int main(){

	int x =5;
	int &y= x;

	cout << x << " " << y << endl;
	y= 20;

	cout << x << " " << y << endl;
	cout << "address of x=  " << &x<<endl;
	cout << "address of y=  " << &y<<endl;
	return 0;
}
