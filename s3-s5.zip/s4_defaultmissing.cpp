#include <iostream>
using namespace std;
class Number {
		int i;
	public:
		//Number(int j) { i=j; }
		int get_i() { return i; }
};
int main() {
	Number ob[3];
	return 0;
}
