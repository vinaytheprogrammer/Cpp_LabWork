#include<bits/stdc++.h>
using namespace std;
class ProbDistribution
{
    public:
	   virtual float getExpectedVal()=0;
	   virtual float getVariance()=0;
};
class BinomailDistribution:public ProbDistribution
{
    protected:
    	float p,n,k;
    public:
	    BinomailDistribution():p(0),n(0),k(0){}
	    BinomailDistribution(float pp,float nn,float kk):p(pp),n(nn),k(kk){}
	    virtual float getExpectedVal(){
	        return(n*p);
	    }
	    virtual float getVariance(){
	        return n*p*k;
	    }
};
class GeometricDistribution:public ProbDistribution
{
    protected:
    	float p,k;
    public:
	    GeometricDistribution():p(0),k(0){}
	    GeometricDistribution(float pp,float kk):p(pp),k(kk){}
	    virtual float getExpectedVal(){
	        return (k/p);
	    }
	    virtual float getVariance(){
	        return k/(p*p);
	    }
};
int main()
{
    BinomailDistribution b(0.7,10,0.3);
    GeometricDistribution g(0.4, 0.6);
    ProbDistribution *p;
    p = &b;
    cout<<"Mean(BD): "<<p->getExpectedVal()<<endl;
    cout<<"Variance(BD): "<<p->getVariance()<<endl<<endl;
    p = &g;
    cout<<"Mean(GD): "<<p->getExpectedVal()<<endl;
    cout<<"Variance(GD): "<<p->getVariance()<<endl;
    return 0;
}