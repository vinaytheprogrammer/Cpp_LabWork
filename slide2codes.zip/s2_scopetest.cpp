#include <iostream>
using namespace std;

int fun(int);
int main(){
	int a;
	int increment(int);
	cout << "input a " <<endl;
	cin >> a;
	a=increment(a);
	cout << "a after increment " << a <<endl;
	a=fun(a);
	cout << "a after increment " << a <<endl;
}

int increment(int x){
	return ++x;
}

int fun(int x){
 x=increment(x);
return x;
}
