#include <iostream>
using namespace std;

class Distance{

	int feet;
	int inches;
	public:
	void setDist(int f,int i){ feet=f; inches=i;}
	void show(void){ 
		cout << "Feets : " << feet << endl;
		cout << "Inches : " << inches << endl;
	}
	Distance operator ++();
	Distance operator ++(int);
//	friend void operator ++(Distance&);
//	friend void operator ++(Distance&,int);
};

Distance Distance::operator ++(){
	++feet;
	++inches; 
	if(inches == 12.0){
		inches = 0.0; 
		++feet;
	}
}
Distance Distance::operator ++(int){
	feet++; 
	inches++; 
	if(inches == 12.0){
		inches = 0.0; 
		feet++;
	}
}

/*void operator ++(Distance &d,int){
	d.meter++;
	d.cm++;
}

void operator ++(Distance &d){
	++d.meter;
	++d.cm;
}*/

int main(){
	Distance d1;
	d1.setDist(10,11);
	d1++;
	cout << "After postfix " << endl;
	d1.show();
	++d1;
	cout << "After prefix " << endl;
	d1.show();
}
	
