// setfill example
#include <iostream>     
#include <iomanip>      
using namespace std;

int main () {
  std::cout << std::setfill ('x') << std::setw (10);
  std::cout << 77 << std::endl;
  return 0;
}
