

	int r=5;
	int c=8;
	int size = r*c;

int main(){
	return 0;
}
