#include<stdio.h>

void fun(int);
void fun(char);

int main(){
	fun(2);
	fun('c');
	return 0;
}

void fun(int val){
	printf("\n fun with int");
}

void fun(char ch){
	printf("\n fun with char");
}
