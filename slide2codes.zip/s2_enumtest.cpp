#include <iostream>
using namespace std;

int main(){
	enum Color { red, blue, green };
	Color c = red;
	c = blue;
	cout << "\n c value " << (Color) c ;
	c = red; // Error in C++
	//++c; // Error in C++
	cout << "c value = " << c;

	return 0;
}
