/*
Write a function to merge two files s.t. the resulting file will contain all elements in
sorted order.
*/
#include <bits/stdc++.h>
using namespace std;

void copy(string file, string target)
{
    ifstream fip1(file);
    ofstream output(target, ios::app);
    string line;
    while (getline(fip1, line))
        output << line;
    output << '\n';
}
void mergeFiles(string file1, string file2, string outputFile)
{
    ofstream ot(outputFile, ios::trunc);
    ot.close();
    copy(file1, outputFile);
    copy(file2, outputFile);
    vector<int> v;
    int e1;
    {
        ifstream output(outputFile);
        while (output >> e1)
            v.push_back(e1);
        output.close();
    }
    {
        ofstream output(outputFile);
        sort(v.begin(), v.end());
        for (auto i : v)
            output << i << " ";
        output.close();
    }
}
int main()
{
    mergeFiles("test.txt", "copyTest.txt", "mergedfile.txt");
    return 0;
}