#include <iostream>
using namespace std;
class Distance{
		int feet;
		float inches;
	public:
		Distance(): feet(0),inches(0.0){}
		Distance(int f, float i): feet(f),inches(i) {}
		Distance(float b){
			feet = int(b);
			inches = 12*(b-feet);
		}
		void showDistance(){
			cout << "Feet : " << feet << endl;
			cout << "Inches : " << inches << endl;
		}
		Distance operator+(Distance);
		//friend Distance operator+(Distance,Distance);
		//Distance operator+(float);
		//Distance operator-(void);
		//bool operator <(Distance);
		//friend Distance operator+(float,Distance);
};

Distance Distance::operator+(Distance d){
	int f = feet+d.feet;
	float i = inches+d.inches;
	if(i>=12.0){
		i-=12.0;
		f++;
	}
	return Distance(f,i);
}/*
Distance Distance::operator+(float b){
	float i = inches + b;
	int f = feet;
	if(i>=12.0){
		i-=12.0;
		f++;
	}
	return Distance(f,i);
}
Distance operator+(float b,Distance d){
	float i = d.inches + b;
	int f = d.feet;
	if(i>=12.0){
		i-=12.0;
		f++;
	}
	return Distance(f,i);
}
Distance operator+(Distance d1, Distance d2){
	int f=d1.feet+d2.feet;
	float i=d1.inches+d2.inches;
	if(i>=12.0){
		i-=12.0;
		f++;
	}
	return Distance(f,i);
}

Distance Distance::operator -(){
	feet=-feet;
	inches=-inches;
}
bool Distance::operator <(Distance d){
	if(feet<d.feet || (feet == d.feet && inches < d.inches))
		return true;
	else
		return false;
}*/
main(){
	Distance d1(10,6), d2(11,5);
	Distance d3=d1+d2;
	d1.showDistance();
	d2.showDistance();
	d3.showDistance();
	Distance d4=d1+d2+d3;
 	d4.showDistance();
	/*Distance d5=d4 + 9.0;
 	d5.showDistance();
	Distance d6 = d5 + 13.0;
 	d6.showDistance();
	float b=34.7;
	d3=b;
	d3.showDistance();
	-d3;
	d3.showDistance();
	cout << (d4<d5) << endl;*/
	
}


