#include <iostream>
using namespace std;

int& fun(int &x, int &y){
	int c=x+y;
	int &d=c;
	cout << "address of d = " << &d << endl;
	return d;
}

int main(){
	int var1,var2;
	var1=10;
	var2=20;
	int &m =fun(var1,var2);
	cout << "address of m = " << &m << endl;
	return 0;
}
