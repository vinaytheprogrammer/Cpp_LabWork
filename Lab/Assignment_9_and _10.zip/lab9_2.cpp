/*
Use a function template to perform insertion sort on the arrays of i. integers, ii.
doubles, iii. Distances (feet, inches)
*/

#include <bits/stdc++.h>
using namespace std;

template <class T>
void Sort(T *a, int n)
{
    for (int i = 1; i < n; i++)
    {
        int j = i - 1;
        T temp = a[i];
        while (a[j] > temp && j >= 0)
        {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = temp;
    }
}
class Distances
{
    int f, i;

public:
    Distances() {}
    Distances(int x, int y) : f(x), i(y) {}
    friend ostream &operator<<(ostream &o, Distances &d)
    {
        o << d.f << " feet," << d.i << " inches \t";
        return o;
    }
    bool operator >(Distances &d)
    {
        float ft=f*12+i,fdt=d.f*12+d.i;
        if(ft>fdt)return true;
        return false;
    }
};

int main()
{
    int a[] = {2, 4, 6, 4, 3, 2, 6, 3};
    int n = sizeof(a) / sizeof(int);
    double d[] = {1.5, 3.2, 43.33, 4, 3};
    for (int i = 0; i < n; i++)
        cout << a[i] << " \n"[i + 1 == n];
    Sort(a, n);
    for (int i = 0; i < n; i++)
        cout << a[i] << " \n"[i + 1 == n];
    n=sizeof(d)/sizeof(double);
    // for (int i = 0; i < n; i++)
    //     cout << d[i] << " \n"[i + 1 == n];
    Sort(d, n);
    for (int i = 0; i < n; i++)
        cout << d[i] << " \n"[i + 1 == n];
    Distances D[]={Distances(2,3),Distances(5,3),Distances(3,3)};
    n = sizeof(D) / sizeof(Distances);
    // for (int i = 0; i < n; i++)
    //     cout << D[i] << " \n"[i + 1 == n];
    Sort(D, n);
    for (int i = 0; i < n; i++)
        cout << D[i] << " \n"[i + 1 == n];
    return 0;
}