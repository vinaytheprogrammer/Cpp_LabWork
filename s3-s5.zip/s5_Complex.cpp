/*Operator Overloading for Complex class*/
#include<iostream>
using namespace std;
class Complex{
	private:
		int re;
		int im;
	public:
		Complex(){
			re=0;
			im=0;
		}
		Complex(int a,int b){
			re=a;
			im=b;
		}
		void show()
		{
			cout<<""<<re<<"+"<<im<<"i"<<endl;
		}
		~Complex(){
			cout<<"\nObjects Destroyed"<<endl;
		}
		Complex operator+(Complex);
		Complex operator-(Complex);
		Complex operator*(Complex);
		Complex operator/(Complex);
		friend ostream& operator<<(ostream &,Complex &);
		friend istream& operator>>(istream &,Complex&);
};
Complex Complex::operator+(Complex c)
{
	int r,i;
	r=re+c.re;
	i=im+c.im;
	return Complex(r,i);
}
/*Complex Complex::operator-(Complex c1)
{
	int r,i;
	if(re>c1.re)
		r=re-c1.re;
	else
		r=c1.re-re;
	if(im>c1.im)
		i=im-c1.im;
	else
		i=c1.im-im;
	return Complex(r,i);
}*/
Complex Complex::operator*(Complex c2)
{
	int r,i;
	r=(re*c2.re)-(im*c2.im);
	i=(re*c2.im)+(im*c2.re);
	return Complex(r,i);
}
Complex Complex::operator/(Complex c3)
{
	int r,i;
	r=((re*c3.re)+(im*c3.im))/((c3.re)*(c3.re)+(c3.im)*(c3.im));
	i=((im*c3.re)-(re*c3.im))/((c3.re)*(c3.re)+(c3.im)*(c3.im));
	return Complex(r,i);
}
ostream& operator<<(ostream &out,Complex &c)
{
	cout<<""<<c.re<<"+i "<<c.im<<endl;
	return out;
}
istream& operator>>(istream &in,Complex &c)
{
	cin>>c.re>>c.im;
	return in;
}
int main()
{
	Complex c1(3,4);
	int a,b,ch,w;
	cout<<"Enter the real part: ";
	cin>>a;
	cout<<"Enter the imaginary part: ";
	cin>>b;
	Complex c2(a,b),c3,c4,c5,c6;
	
	while(w!=0)
	{
		cout<<"Press \n1.Add Two Complex Numbers \n2.Subtract Two Complex Numbers \n3.Multiply Two Complex Numbers \n4.Divide Two 				Complex Numbers"<<endl;
		cout<<"Select: ";
		cin>>ch;
		c1.show();
		c2.show();
		switch(ch)
		{
			case 1:
				c3=c1+c2;
				c3.show();
				break;
			case 2:
				c4=c1-c2;
				c4.show();
				break;
			case 3:
				c5=c1*c2;
				c5.show();
				break;
			case 4:
				c6=c1/c2;
				c6.show();
				break;
			default:
				return(0);				
		}
		cout<<"Do You Wish to Continue ? \nPress 1 to continue or 0 to break : ";
		cin>>w;
	}
	cout<<"\nThank You\n";
}
