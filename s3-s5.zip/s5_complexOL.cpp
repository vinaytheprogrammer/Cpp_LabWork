#include<iostream>
using namespace std;

class Complex{
    int re;
    int im;
    public:
	Complex(int r, int i): re(r), im(i) {}
	void show(){ cout << re << "+i" << im << endl; }
	Complex operator+=(Complex);
	Complex operator+=(double);
	friend Complex operator +(double,Complex);
	friend Complex operator +(Complex,double);
	friend ostream& operator<<(ostream&,Complex&);
	friend istream& operator>>(istream&,Complex&);
};
//member functions
Complex Complex::operator +=(Complex a){
	re+=a.re;
	im+=a.im;
//	return *this;
}
Complex Complex::operator +=(double a){
	re+=a;
//	return *this;
}

//friend functions
Complex operator +(double a, Complex b){
	Complex r = b;
	r+=a;
	return r;
}
Complex operator +(Complex a, double b){
	Complex r=a;
	r+=b;
	return r;
}

ostream& operator<<(ostream& out,Complex &c){
	out<< c.re << " + i" << c.im << endl;
	return out;
}
istream& operator>>(istream& in,Complex &c){
	in >> c.re >> c.im;
	return in;
} 

int main(){

	Complex c1(2,3);
	Complex c2(4,5);
	cout << "Input first complex number :" << endl;
	cin >> c1;
	cout << "Input second complex number :" << endl;
	cin >> c2;

	double b = 10.0;
	c1+=c2;
	cout << c1;
	c1+=b;
	c1.show();
	double x = 7.4;
	c2 = c2 + x;
	c2.show();
	c2 = x + c2;
	c2.show();
	return 0;
}


