#include<iostream>
using namespace std;

void myplus(int[],int[],int[]);
void myplus(int,int,int);

int main(){
	int arr[10]={1,2,3,4,5};
	myplus(arr,arr,arr);
	myplus(1,2,3);
	return 0;
}

void myplus(int arr[10], int ar2r[20], int arr3[5] ){
	cout << "hello";
}

void myplus(int a,int b,int c){
	cout << "hiii";
}
