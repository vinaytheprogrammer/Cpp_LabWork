#include<bits/stdc++.h>
using namespace std;
class student
{
    protected:
    string name;int rollno;
    public:
    void get(int n,string st)
    {
        name=st;
        rollno=n;
    }
    void put()
    {
        cout<<"Name : "<<name<<"\n"<<"Rollno. : "<<rollno<<"\n";
    }
};
class sports:public virtual student
{
    protected:
    int score;
    public:
    void get_score(int n)
    {
        score=n;
    }
    void put_score(){
        cout<<"Sports Score : "<<score<<"\n";
    }
};
class Marks:public virtual student
{
    protected:
    int m1,m2;
    public:
    void get_marks(int n,int m)
    {
        m1=m;m2=n;
    }
    void put_marks(){
        cout<<"Marks1 : "<<m1<<" "<<"Marks : "<<m2<<"\n";
    }
};
class Result:public sports,public Marks
{
    protected:
    float total;
    public:
    void display()
    {
        total=score+m1+m2;
        cout<<"Total Marks : "<<total;
    }
};
int main()
{
    Result tr;
    tr.get(56,"devvrat");
    tr.put();
    tr.get_marks(45,78);
    tr.put_marks();
    tr.get_score(90);
    tr.put_score();
    tr.display();
    return 0;
}