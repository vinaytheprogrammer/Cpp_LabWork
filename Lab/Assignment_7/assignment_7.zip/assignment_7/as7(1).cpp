#include<bits/stdc++.h>
using namespace std;
class FamilyMember
{
  protected:
  	string name;
  	string familyname;
  	string origin;
  public:
      FamilyMember(string n, string f, string o){
          name.assign(n);
          familyname.assign(f);
          origin.assign(o);
      }
      ~FamilyMember(){
          cout<<"FamilyMember Desctructor!"<<endl;
      }
	  virtual void about(){
	      cout<<"\nName: "<<name;
	      cout<<"\nFamily name: "<<familyname;
	      cout<<"\nOrigin: "<<origin;
	      cout<<endl;
	  }
};
class Citizen
{
  protected:
  	string name;
  	string country;
  	string year;
  public:
      Citizen(string n, string c, string y){
          name.assign(n);
          country.assign(c);
          year.assign(y);
      }
      ~Citizen(){
          cout<<"Citizen Desctructor!"<<endl;
      }
	  virtual void about(){
	      cout<<"\nName: "<<name;
	      cout<<"\nCountry: "<<country;
	      cout<<"\nYear: "<<year;
	      cout<<endl;
	  }
};
class Employee:public FamilyMember, public Citizen{
  private:
    string name;
  public:
    Employee(string n, string n1, string f, string o, string n2, string c, string y):FamilyMember(n1,f,o), Citizen(n2,c,y)
    {
        name.assign(n);
    }
    ~Employee(){
        cout<<"Employee Destructor.!"<<endl;
    }
    void about(){
        cout<<endl<<"Father Details:-";
        FamilyMember::about();
        cout<<endl<<"Mother Details:-";
        Citizen::about();
        cout<<endl<<"Name: "<<name<<endl;
    }
};
int main()
{
    string my,f,m,family,org,ctry,yr;
    cout<<"Emter your name: ";
    cin>>my;
    cout<<"Enter your father's name: ";
    cin>>f;
    cout<<"Enter your family name: ";
    cin>>family;
    cout<<"Enter the origin place of the family: ";
    cin>>org;
    cout<<"Enter your mother's name: ";
    cin>>m;
    cout<<"Enter the country you live in: ";
    cin>>ctry;
    cout<<"Enter the year you moved to this country: ";
    cin>>yr;
    Employee e(my,f,family,org,m,ctry,yr);
    FamilyMember *fam;
    fam = &e;
    fam->about();
    return 0;
}