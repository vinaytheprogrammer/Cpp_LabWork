#include <iostream>
using namespace std;
class pwr {
	double b;
	int e;
	double val;

	public:
	pwr(double base, int exp);
	double get_pwr() { return val; }
};

pwr::pwr(double b, int e) {
	this->b = b;
	this->e = e;
	this->val = 1;
	for( ; e>0; e--) this->val = this->val * this->b;
	cout << (*this).get_pwr() << " ";
}
int main(){
	pwr x(4.0, 2), y(2.5, 1), z(5.7, 0);
	cout << x.get_pwr() << " ";
	cout << y.get_pwr() << " ";
	cout << z.get_pwr() << "\n";
	return 0;
}

