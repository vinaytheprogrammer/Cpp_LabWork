// demonstrates passing and returning a structure
#include <iostream>
using namespace std;

struct Distance {
	int feet;
	float inches;
};

void addDist(Distance&, Distance&); 
void dispDist(Distance);

int main() {
Distance d1, d2, d3;
    cout << "\nEnter feet: "; cin >> d1.feet;
    cout << "Enter inches: "; cin >> d1.inches;

    cout << "\nEnter feet: "; cin >> d2.feet;
    cout << "Enter inches: "; cin >> d2.inches;
    addDist(d1, d2);
    cout << endl;
    //dispDist(d1); cout << " + "; 
    //dispDist(d2); cout << " = ";
    dispDist(d1); cout << endl;
    return 0;
}

// adds two structures of type Distance, returns sum
void addDist( Distance &dd1, Distance &dd2 ) {
    //Distance dd3;
    dd1.inches += dd2.inches;
    int feet = 0;
    if(dd1.inches >= 12.0) {
	dd1.inches -= 12.0; //by 12.0 and
	feet++; //increase feet
    } 
    dd1.feet += feet + dd2.feet; //add the feet
    return; //return structure
}


void dispDist( Distance dd ) {
    cout << dd.feet << "\'-" << dd.inches << "\"";
}
