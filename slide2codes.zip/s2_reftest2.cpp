#include<iostream>
#include <stdio.h>
#include <string.h>
using namespace std;
int main(){
	int a;
	int b=10;
	int &refb=b;
	cout << "the address via b is " << &refb <<endl;
	cout << "the address via reference is " << &refb <<endl;
	return 0;
}
