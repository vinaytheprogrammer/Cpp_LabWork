#include <iostream>
using namespace std;
class Number {
	public:
	Number (int i) { val=i; }
	int val;
	int double_val() { return val+val; }
};

int main() {
	int Number::*data; // data member pointer
	int (Number::*func)(); // function member pointer
	Number ob1(1), ob2(2);
	data = &Number::val; // get offset of val
	func = &Number::double_val; // get offset of double_val()
	cout << "Original values: ";
	cout << ob1.*data << " " << ob2.*data << "\n";
	cout << "Doubled values: ";
	cout << (ob1.*func)() << " ";
	cout << (ob2.*func)() << "\n";
	return 0;
}

