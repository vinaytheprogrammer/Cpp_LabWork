#include<iostream>
#include<malloc.h>
using namespace std;

int main(){
	int *ptr;
	ptr=(int *)  malloc(5*sizeof(int));
	ptr[0]=10;
	ptr[1]=20;

	cout << ptr[0] <<endl;
	free(ptr);
	return 0;
}

