#include <iostream>
using namespace std;

class Point2D;
class Circle{
 	int centerX;
	int centerY;
	int rad;
	public:
	void show(){
		cout << "Center : " << centerX << centerY << endl;
		cout << "Radius : " << rad << endl;
	}
	void setValues(Point2D,int);
};


class Point2D{

	int xco;
	int yco;
	public:
	int getX(void) { return xco; }
	int getY(void) { return xco; }
	void setPoint(int x,int y){ xco =x; yco =y; }
	friend void Circle::setValues(Point2D,int);
};

void Circle::setValues(Point2D p, int r){
		centerX = p.xco;
		centerY = p.yco;
		rad = r;
}

	
int main(){
	Circle ob1;
	Point2D pt1;
	pt1.setPoint(10,20);
	ob1.setValues(pt1,7);
	ob1.show();
}
