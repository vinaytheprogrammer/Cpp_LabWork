#include <iostream>
using namespace std;
int a=10;
int b=20;
int c=a*b;
int main(){

	for(int i=1;i<10;i++)
	    cout << "i= " << i << endl;
	int i =40;
	cout << "after loop i= " << i << endl;
	return 0;
}
