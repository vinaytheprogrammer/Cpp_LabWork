#include <iostream>
using namespace std;

class Time{
	
    private:
	int hour;
	int min;
	int sec;
    public:
	void setHour(int h)  { hour = h; }
	int getHour() { return hour; }
	void setMin(int m)  { min = m;}
	int getMin() { return min; }
	void setSec(int s)  { sec = s;}
	int getSec() { return sec; }

	void addTime(Time,Time);
	void diffTime(Time,Time);
	void convertTime(int);
};

void Time::addTime(Time t1, Time t2){
	sec = t1.sec + t2.sec;
	if(sec >= 60){
		sec %= 60;
		min = t1.min + t2.min+1;
	}
	else
		min = t1.min + t2.min;

	if(min >= 60){
		min = min % 60;
		hour = t1.hour + t2.hour + 1;
	}else
		hour = t1.hour + t2.hour;
}

void Time::diffTime(Time t1, Time t2){
	if(t1.sec > t2.sec)
		sec = t1.sec - t2.sec;
	else{
		sec = t1.sec + 60 - t2.sec;
		t1.min--;
	}
	if(t1.min > t2.min)
		min = t1.min - t2.min;
	else{
		min = t1.min + 60 - t2.min;
		t1.hour--;
	}
	hour = t1.hour - t2.hour;

}
void Time::convertTime(int timeinsec){
	min = timeinsec / 60;
	hour = min /60;
	min %= 60;
	sec = timeinsec % 60;
}

int main(){
	Time t1,t2;
	int temph, tempm,temps;
	cout << " data for time 1 " << endl;
	cin >> temph >> tempm >> temps;
	t1.setHour(temph);
	t1.setMin(tempm);
	t1.setSec(temps);
	cout << " data for time 2 " << endl;
	cin >> temph >> tempm  >> temps;
	t2.setHour(temph);
	t2.setMin(tempm);
	t2.setSec(temps);
	cout << "time 1 - " << t1.getHour() << " : " << t1.getMin() << " : " << t1.getSec() << endl;
	cout << "time 2 - " << t2.getHour() << " : " << t2.getMin() << " : " << t2.getSec() << endl;
	Time t3;
	t3.addTime(t1,t2);
	cout << "time 3 - addition " << t3.getHour() << " : " << t3.getMin() << " : " <<  t3.getSec() << endl;
	t3.diffTime(t1,t2);
	cout << "time 3 - difference " << t3.getHour() << " : " << t3.getMin() << " : " <<  t3.getSec() << endl;

	cout << "Enter time in seconds" << endl;
	cin >> temps;
	t3.convertTime(temps);
	cout << "time 4 - Converted" << t3.getHour() << " : " << t3.getMin() << " : " <<  t3.getSec() << endl;

	return 0;
}

