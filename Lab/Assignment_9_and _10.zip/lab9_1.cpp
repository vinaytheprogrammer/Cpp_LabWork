/*
1) To print an array of elements, use a function template for arrays of i. integers, ii.
    doubles, iii.Strings, and iv. Complex numbers
*/

#include<bits/stdc++.h>
using namespace std;

template<class T>
void print(T arr[],int n){
    for(int i=0;i<n;i++) cout<<arr[i]<<' ';
    cout<<endl;
}

class Complex{
    int a,b;
    public:
        Complex(int x,int y) : a(x),b(y) {}
        friend ostream& operator<<(ostream& o,Complex& c){
            o<<c.a<<"+i"<<c.b;
            return o;
        }
};

int main()
{
    int arr[5]={1,3,4,5,2};
    double brr[4]={1.2,3.1,4.6,6.9};
    string crr[3]={"aakash","hemendra","mehra"};
    Complex drr[3]={Complex(2,3),Complex(1,2),Complex(5,6)};
    print(arr,5);
    print(brr,4);
    print(crr,3);
    print(drr,4);
    return 0;
}