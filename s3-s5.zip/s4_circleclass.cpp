#include <iostream>
using namespace std;

class circle{
	private:
	int xco;
	int yco;
	float radius;
	public:
	void setdata(int x, int y, float r){
		xco = x;
		yco = y;
		radius =r;
	}
	float area(void){
		return 3.14*radius*radius;
	}
};

int main(){
	circle c1;
	
	c1.setdata(3,5,2.5);
	cout << "Area of circle is " << c1.area() << endl;
}

