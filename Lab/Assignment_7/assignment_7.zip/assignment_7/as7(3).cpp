#include<bits/stdc++.h>
using namespace std;
class Shape2D
{
    protected:
    string type;
    public:
    Shape2D(string st){type=st;}
    virtual void area()=0;
    virtual void permi()=0;
};
class Circle:public Shape2D
{
    protected:
    int radius,center;
    public:
    Circle(int r,int c, string t):Shape2D(t)
    {
        radius=r;center=c;
    }
    virtual void area(){
        int area =  3.14*radius*radius;
        cout<<"\nArea(C): "<<area;
    }
    virtual void permi(){
        int perimeter =  2*2.14*radius;
        cout<<"\nPerimeter(C): "<<perimeter;
    }
    void print(){
        area();
        permi();}
};
class Trianngle:public Shape2D
{
    protected:
    int height,base,ar;
    public:
    Trianngle(int h,int bs):Shape2D("Trianngle")
    {
        height=h;base=bs;
    }
    virtual void area(){
        int a = (base*height)/2;
        cout<<"\nArea(T): "<<a;
    }
    virtual void permi(){
        int p = (base*3);
        cout<<"\nPerimeter(T): "<<p<<endl;
    }
    void print(){
        area();
        permi();
    }
};
int main()
{
    Shape2D *ptr;
    Circle ct(4,6,"circle");
    ptr = &ct;
    ptr->area();
    ptr->permi();
    Trianngle tri(6,8);
    ptr=&tri;
    ptr->area();
    ptr->permi();
}

