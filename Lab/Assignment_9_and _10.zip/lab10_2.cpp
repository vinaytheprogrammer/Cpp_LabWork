/*
Write a program to input a word and count the number occurrences of the word
in a given file.
*/

#include <bits/stdc++.h>
using namespace std;

int main()
{
    ifstream fip;
    fip.open("test.txt");
    string s, line;
    cin >> s;
    int cnt = 0;

    while (getline(fip, line))
    {
        size_t pos = 0;
        while ((pos = line.find(s, pos)) != string::npos)
        {
            cnt++;
            pos += s.length();
        }
    }
    cout << s << " occured " << cnt << " times in the file\n";
    fip.close();

    return 0;
}