#include <iostream>
using namespace std;

int& max(int &x, int &y){
	return x>y ? x:y;
}

int main(){			 	
	int i=2,j=3;
	max(i,j)= -30;
	cout << "i="<< i<<'\t' << "j="<< j <<'\t'<< endl;
	return 0;
}

