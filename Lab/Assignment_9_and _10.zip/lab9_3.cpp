/*
Queue implementation using a Vector of STL
*/

#include<bits/stdc++.h>
using namespace std;

template<class T>
struct Queue{
    int front=-1,rear=-1;
    vector<T> q;
    void insert(){
        T n;
        cout<<"Enter element: "; cin>>n;
        if(front==-1) front++;
        rear++;
        q.push_back(n);
    }

    void display(){
        if(front==-1) cout<<"Queue is empty\n";
        for(int i=front;i<=rear;i++) cout<<q[i]<<' ';
        cout<<endl;
    }

    void del(){
        if(front==-1) cout<<"Queue is empty\n";
        front++;
        if(front>rear){
        front=-1;
        rear=-1;
        }
    }
};

int main()
{
    int ch;
    Queue<double> q1;
    cout<<"\n1.Insert element.\n2.Display\n3.Delete\n4.Exit\n";
    while(1){
        cout<<"Enter choice : ";
        cin>>ch;
        switch(ch){
            case 1: q1.insert(); break;
            case 2: q1.display(); break;
            case 3: q1.del(); break;
            case 4: exit(0);
        }
    }
    return 0;
}