#include<iostream>
using namespace std;

int main(){
	
	int a,*ptr=NULL;
	void *vptr;
	a=10;
	ptr=&a;
	vptr= (void *)ptr;
	cout << vptr << endl;
	cout << *(static_cast<int*>(vptr));
	return 0;
}
