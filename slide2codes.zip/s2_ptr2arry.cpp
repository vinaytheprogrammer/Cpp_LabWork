#include<iostream>
using namespace std;

int main(){
	int (*ptr)[5] = new int[4][5];
	for(int i=0;i<4;i++)
		for(int j=0;j<5;j++)
			cin >> ptr[i][j];
	
	for(int i=0;i<4;i++){
		for(int j=0;j<5;j++)
			cout << ptr[i][j] << " ";
		cout << endl;
	}
	return 0;
}
