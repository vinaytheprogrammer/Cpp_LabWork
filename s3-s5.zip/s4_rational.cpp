#include<iostream>
using namespace std;

class Rational{
   int num;
   int denom;
   public:
   Rational(){num = denom = 0;}
   Rational(int n, int d):num(n),denom(d){}
   Rational(const Rational &r){
	cout << "Copy constructor is called"<<endl;
	num=r.num;
	denom=r.denom;
   }
   Rational operator+(Rational&);
   Rational operator++(void);
   Rational operator *(Rational&);
   friend Rational operator /(Rational &, Rational &);
   friend void operator ++(Rational &, int);	
   friend Rational operator -(Rational&, Rational&);	
   friend ostream & operator <<(ostream &, Rational &); 	
};

Rational Rational::operator +(Rational &r2){
	int n,d;
	n=num*r2.denom+denom*r2.num;
	d=denom*r2.denom;
	return Rational(n,d);	
}

Rational operator -(Rational &r1, Rational &r2){

	int n,d;
	n=r1.num*r2.denom-r1.denom*r2.num;
	d=r1.denom*r2.denom;
	return Rational(n,d);	
}

Rational Rational::operator ++(void){
	num=num+denom;
}

void operator++(Rational &r,int){
	r.num=r.num+r.denom;
	
}
ostream & operator <<(ostream & out, Rational &r){
	out << r.num << "/" << r.denom << endl;
	return out;
}

Rational Rational::operator*(Rational &r2){
	Rational res;
	res.num = num*r2.num;
	res.denom = denom*r2.denom;
	return res;
}

Rational operator /(Rational &r1, Rational &r2){
	int n,d;
	n=r1.num*r2.denom;
	d=r1.denom*r2.num;
	return Rational(n,d);
}

int main(){
	Rational r1(2,5),r2(3,7);
	Rational r3 = r1 + r2;
	cout << r3;	
	Rational r4 = r1 - r2;
	cout << r4;
	++r1;
	cout << r1;
	r2++;
	cout << r2;
	return 0;
}
