#include <iostream>
#include <string.h>
using namespace std;

class Employee{
	char* Name;
	static int count; 
	public:
	Employee(char*);
	char* getName();
	static int getCount();
	~Employee();
};

int Employee::count=0;
int Employee::getCount()
	{return count;}
Employee::Employee(char* N){
	Name=new char[strlen(N)+1];
	strcpy(Name,N);
	++count; 
}
Employee::~Employee(){
		delete [] Name;
		--count;
}
char* Employee::getName(){
	return Name;
}

main(){
	cout<<"no of Employees: "<< Employee::getCount()<<endl;

    	Employee* e1= new Employee((char*)"Bob");
	Employee* e2= new Employee((char*)"John");

	cout<<"no of employees: " << e1->getCount() <<endl ;
	cout<<"Emp1: "<<e1->getName() <<endl ;
	cout<<"Emp2: "<<e2->getName() <<endl ;
	delete e1;
	cout<<"no of employees: "<<e2->getCount() <<endl ;
	delete e2;
	cout<<"no of employees: " << Employee::getCount();
}
