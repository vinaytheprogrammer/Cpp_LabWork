#include <iostream>
using namespace std;

class Distance {
    private:
	int feet;
	float inches;
    public:
	Distance() : feet(0), inches(0.0) { }
	Distance(int ft, float in) : feet(ft), inches(in) { }
	Distance(const Distance& ob) {
		feet = ob.feet; inches = ob.inches;
	}
	void showdist() {
		cout << feet << "\'-" << inches << '\"'; 
	}
};
int main() {
	Distance dist1(11, 6.25);
	Distance dist2(dist1);
	Distance dist3 = dist1;
	cout << " \n dist1 = "; dist1.showdist();
	cout << " \n dist2 = "; dist2.showdist();
	cout << " \n dist3 = "; dist3.showdist();
	cout << endl;
	return 0;
}
