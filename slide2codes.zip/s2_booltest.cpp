#include<iostream>
using namespace std;

int main(){
	int val1=40,val2=0,val3;
	bool res;
	res=val1 && val2;
	val3=res;
	cout << "res=" << res << " val3=" << val3 << "\n";
	return 0;

	
}

