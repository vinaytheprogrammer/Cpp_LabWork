//Matrix Vector product
#include <iostream>
using namespace std;

class Matrix;
class Vector{
	int v[4];
	public:
	void setVector(int vec[4]){
		for(int i=0;i<4;i++){
			v[i]=vec[i];
		}
	}
	void showVec(void){
		cout << v[0] << " " << v[1] << " " << v[2] << " " << v[3] << endl;

	}
	friend Vector operator* (Matrix &,Vector &);
};
class Matrix{
	Vector m[4];
	public:

	void setMat(int[][4]);
	void showMat(void);
	friend Vector operator*(Matrix&, Vector&);
};

void Matrix::setMat(int mat[][4]){
    for(int i=0;i<4;i++)
	    m[i].setVector(mat[i]);
}

void Matrix::showMat(void){
    for(int i=0;i<4;i++)
	m[i].showVec();
	    
}

Vector operator *(Matrix& mat, Vector& vec){
	Vector res;
	for(int i=0;i<4;i++){
		res.v[i]=0;
		for(int j=0;j<4;j++)
		res.v[i]+=mat.m[i].v[j]*vec.v[j];
	}
	return res;
} 


int main(){
	Matrix mat1;
	Vector vec1,vec2;
	int v[4], m[4][4];
	cout << "enter the vector" <<endl;
	cin >> v[0] >> v[1] >> v[2] >> v[3];
	vec1.setVector(v);
	cout << "enter the matrix " << endl;
	for(int i=0;i<4;i++)
	    for(int j=0;j<4;j++)
		cin >> m[i][j];
	mat1.setMat(m);
	mat1.showMat();
	vec2 = mat1 * vec1;
	cout << "Result vector" <<endl;
	vec2.showVec();
	
	return 0;
}
