#include <iostream>

using namespace std;
#include <string.h>

class student{
	private:
	int roll;
	char name[10];
	int age;
	float cgpa;
	public:
	void input(void){
		cout << "Enter name :" << endl;
		cin >> name;
		cout << " Roll No. :" <<endl;
		cin >> roll;
		cout << " Enter age and cgpa" << endl;
		cin >> age >> cgpa;
	}
	void showdata(void){
		cout << "Name :" << name << endl;
		cout << " Roll No. :" << roll << endl;
		cout << " Age" << age << endl;
		cout << " CGPA " << cgpa << endl;
	}
	
};

int main(){
	student stud[5];
	
	for(int i=0;i<5;i++){
		stud[i].input();
		cout << "Information of student -" << i << endl;
		stud[i].showdata();
	}
}
