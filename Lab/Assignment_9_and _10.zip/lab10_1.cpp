/*

Write a program to count the number of words, and lines present in a given file.

*/
#include <bits/stdc++.h>
using namespace std;

int main()
{
    ifstream fip;
    fip.open("test.txt");
    int wCnt = 0, lCnt = 0;
    string s;
    while (getline(fip, s))
    {
        for (int i = 0; i < s.length(); i++)
            if (s[i] == ' '|| i == s.length() - 1)
                wCnt++;            
        lCnt++;
    }
    cout << "\nWord count : " << wCnt << "\tLine count : " << lCnt << endl;
    fip.close();

    return 0;
}