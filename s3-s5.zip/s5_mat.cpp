#include<iostream>
#include<stdlib.h>
using namespace std;
class matrix{
   public:
   	int a[3][3];
   	matrix()//default constructor
    	{
      	  for(int i=0;i<3;i++)
      	  {
      	      for(int j=0;j<3;j++)
      	      {
      	          a[i][j]=0;
        	    }
	        }
	    }
	   void set()// to set matrix elements
	   {
	      for(int i=0;i<3;i++)
   	   {
   	      for(int j=0;j<3;j++)
   	      {
   	      	cout<<"\n Enter "<<i<<","<<j<<" element=";
   	         cin>>a[i][j];
   	      }
   	   }
    	}
    	void show()// to show matrix elements
    	{
      	cout<<"\n Matrix is=\n";
        	for(int i=0;i<3;i++)
        	{
        		cout<<"|";
            for(int j=0;j<3;j++)
            {
            	cout<<a[i][j]<<" ";  
            }
            cout<<"|";
            cout<<"\n";
        	}
    	}
   	matrix operator+(matrix);
   	matrix operator-(matrix);
   	matrix operator*(matrix);
  	 	friend ostream& operator<<(ostream&,matrix&);
		friend istream& operator>>(istream&,matrix&);
};
matrix matrix::operator +(matrix m)
{
	matrix m1;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m1.a[i][j]=m.a[i][j]+a[i][j];
		}
	}
	return(m1);
}
matrix matrix::operator-(matrix m)
{
	matrix m2;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m2.a[i][j]=m.a[i][j]-a[i][j];
		}
	}
	return(m2);
}
matrix matrix:: operator*(matrix x)// overloading * for multiplication
{
        matrix c;// this will hold our result
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                c.a[i][j]=0;
                for(int k=0;k<3;k++)
                {
                    c.a[i][j]=c.a[i][j]+a[i][k]*x.a[k][j];        
                }
            }
        }
        return(c);
        
}
ostream& operator<<(ostream& out,matrix& m)
{
	for(int i=0;i<3;i++)
	{
		out<<"|";
		for(int j=0;j<3;j++)
		{
			out<<m.a[i][j]<<" ";
		}
		out<<"|\n";
	}
	return out;
}
istream& operator>>(istream& in,matrix& d)
{
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			in>>d.a[i][j];
		}
	}
	return in;
}

int main()
{
	int w,ch;
   matrix a,b,c,d,e;
   cin >> a;
   cin >> b;
   cout<<"Press \n1.Add Two Matrix \n2.Subtract Two Matrix \n3.Multiply Two Matrix \n";
	cout<<"Press 1 to continue : ";
	cin>>w;
	while (w!=0)
	{
	 	cout<<"\nSelect: ";
	 	cin>>ch;
	 	a.show();
	 	b.show();
	 	switch(ch)
	 	{
	 		case 1:
	 			c=a+b;
	 			//c.show();
				cout << c;
	 			break;
	 		case 2:
	 			d=a-b;
	 			d.show();
	 			break;
	 		case 3:
	 			e=a*b;
	 			e.show();
	 			break;
	 		default:
	 			return(0);
		}
		cout<<"Do you wish to continue ? \nPress 1 to continue or 0 to break: ";
		cin>>w;
	}
	cout<<"Thank You"<<endl;
 }
