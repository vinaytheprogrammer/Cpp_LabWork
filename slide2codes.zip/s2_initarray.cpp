#include <iostream>
using namespace std;

int main(){
	int a=3, b=5;
	int arr[5]= {a+1, a+2, b*2, b*3, a/3};

	cout << arr[0] << " " << arr[2] << " " << arr[4] << endl;

	return 0;
}
