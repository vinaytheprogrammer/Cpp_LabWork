/*Overloading Time class with binary and unary operators*/
#include<iostream>
using namespace std;
class Time{
	private:
		int h;
		int m;
		int s;
	public:
		Time(){
			h=0;
			m=0;
			s=0;
		}
		Time(int x,int y,int z){
			h=x;
			m=y;
			s=z;
		}
		~Time(){
			cout<<"\nObject Destroyed for class Time"<<endl;
		}
		void show()
		{
			cout<<""<<h<<" ::"<<m<<" ::"<<s<<endl; 
		}
		Time operator+(Time);
		Time operator-(Time);
		Time operator++(int);
		Time operator --(int);
		friend ostream& operator<<(ostream&,Time &);
		friend istream& operator>>(istream&,Time &);
};
Time Time::operator+(Time t)
{
	int hr,mn,sc;
	sc=s+t.s;
	mn=m+t.m;
	hr=h+t.h;
	if(sc>=60)
	{
		sc-=60;
		mn+=1;
	}
	if(mn>=60)
	{
		mn-=60;
		hr+=1;
	}
	return Time(hr,mn,sc);
}
Time Time::operator-(Time t)
{
	int hr,mn,sc;
	if(s>t.s)
		sc=s-t.s;
	else
		sc=t.s-s;
	if(m>t.m)
		mn=m-t.m;
	else
		mn=t.m-m;
	if(h>t.h)
		hr=h-t.h;
	else
		hr=t.h-h;
	return Time(hr,mn,sc);
}
Time Time::operator++(int)
{
	s++;
	if(s>60)
	{
		s-=60;
		m++;
	}
	m++;
	if(m>60)
	{
		m-=60;
		h++;
	}
	h++;
}
Time Time::operator --(int)
{
	s--;
	m--;
	h--;
}
ostream& operator<<(ostream& out,Time &t)
{
	out<<"Hours: "<<t.h<<"  Minutes: "<<t.m<<"  Seconds: "<<t.s<<endl;
	return out;
}
istream& operator>>(istream& in,Time &t)
{
	in>>t.h>>t.m>>t.s;
	return in;
}
int main()
{
	int x,y,z,w,ch;
	cout<<"=============="<<endl;
	cout<<"Enter Hours: ";
	cin>>x;
	cout<<"Enter Minutes: ";
	cin>>y;
	cout<<"Enter Seconds: ";
	cin>>z;
	cout<<"=============="<<endl;
	Time t1(x,y,z);
	Time t2(1,35,20),t3,t4;
	cout<<"Press \n1.Add two time \n2.Subtract two time \n3.Increment the Time \n4.Decrement the Time ";
	while(w!=0)
	{
		cout<<"\nSelect: ";
		cin>>ch;
		t1.show();
		t2.show();	
		switch(ch)
		{
			case 1:
				t3=t1+t2;
				t3.show();
				break;
			case 2:
				t4=t1-t2;
				t4.show();
				break;
			case 3:
				t1++;
				t1.show();
				break;
			case 4:
				t1--;
				t1.show();
				break;
			default:
				return(0);
		}
		cout<<"Do You wish to continue ? \nPress 1 to continue or 0 to break : ";
		cin>>w;
	}
	cout<<"\nThank You "<<endl;
}
