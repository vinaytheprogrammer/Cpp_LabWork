#include <iostream>
using namespace std;
class Distance {
    private:
	int feet;
	float inches;
    public:
	void set_dist(int f, float in){ feet = f; inches = in; }
	void show_dist(void){ cout << feet << "\' " << inches << "\"" << endl; }
	void add_dist( Distance, Distance );
};

void Distance::add_dist(Distance d2, Distance d3) {
	inches = d2.inches + d3.inches;
	feet = 0;
	if(inches >= 12.0) {
		inches -= 12.0;
		feet++;
	}
	feet += d2.feet + d3.feet;
}

int main() {
    Distance dist1, dist2, dist3;
	cout << "Size of distance object " << sizeof(dist1);

    return 0;
}
