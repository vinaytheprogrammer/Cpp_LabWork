#include <iostream>
#include <string.h>
using namespace std;

class BankAcc{
	
    private:
    unsigned int accno;
    char *name;
    char *address;
    double balance;
   
    public:
    BankAcc(unsigned int, char *, char *, double);
    BankAcc(const BankAcc&);
    void withdraw(double);
    void deposit(double);
    void Display(void);
};

    
	

