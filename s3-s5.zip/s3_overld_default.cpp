// demonstrates function overloading
#include <iostream>
using namespace std;

void repchar(char='*', int=45);

int main() {
	//double val=900.478;
	repchar();
	repchar('=');
	repchar('+', 30);
	return 0;
}

void repchar(char ch, int n) {
for(int j=0; j<n; j++)
	cout << ch;
	cout << endl;
}

